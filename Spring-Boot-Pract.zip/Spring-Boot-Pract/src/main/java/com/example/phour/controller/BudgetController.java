package com.example.phour.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.phour.model.Budget;

@RestController
@RequestMapping("/budget")
public class BudgetController {
	
	List<Budget> budgetList = new ArrayList<>();
	
	public BudgetController() {
        budgetList.add(new Budget(101, 201, "Home", 5000, "April"));
        budgetList.add(new Budget(102, 202, "Health", 6000, "May"));
        budgetList.add(new Budget(103, 203, "Sport", 4000, "June"));
        budgetList.add(new Budget(104, 204, "Entertainment", 5000, "April"));
        budgetList.add(new Budget(105, 205, "Travel", 5000, "Aug"));
    }
	
	@GetMapping("/getall")
	public List<Budget> gelAllBudget(){
		return this.budgetList;
	}
	
	@GetMapping("/{bid}")
	public Budget getBudgetById(@PathVariable("bid") int bid) {
		System.out.println(bid);
		Budget budget = null;
		Iterator<Budget> itr = budgetList.iterator();
		while (itr.hasNext()) {
            Budget currentBudget = itr.next();
            if (currentBudget.getId() == bid) {
            	budget = currentBudget;
                break;
            }
        }
		return budget;
	}
	
	@PostMapping("/add")
	public Budget addBudget(@RequestBody Budget budget) {
		budgetList.add(budget);
		return budget;
	}
	
	@PutMapping("/update/{bid}/{amount}")
	public String updateBudget(@PathVariable("bid") int bid, @PathVariable("amount") double amount) {
		for(Budget b:budgetList) {
			if(b.getId()==bid) {
				b.setAmount(amount);
			}
		}
		return "Budget Updated";
	}
	

}
