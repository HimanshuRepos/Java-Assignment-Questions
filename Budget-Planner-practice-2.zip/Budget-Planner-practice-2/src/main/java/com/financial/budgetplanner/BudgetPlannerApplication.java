package com.financial.budgetplanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
public class BudgetPlannerApplication {
    public static void main(String[] args) {
        SpringApplication.run(BudgetPlannerApplication.class, args);
    }
}

