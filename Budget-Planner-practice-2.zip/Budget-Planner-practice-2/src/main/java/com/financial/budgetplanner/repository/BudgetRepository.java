package com.financial.budgetplanner.repository;

import com.financial.budgetplanner.model.Budget;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class BudgetRepository {

    private final List<Budget> budgets = new ArrayList<>();

    public List<Budget> findAll() {
        return budgets;
    }

    public Optional<Budget> findById(Long id) {
        return budgets.stream().filter(budget -> budget.getId().equals(id)).findFirst();
    }

    public void save(Budget budget) {
        budgets.add(budget);
    }

    public void deleteById(Long id) {
        budgets.removeIf(budget -> budget.getId().equals(id));
    }
}
