package com.financial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BudgetPlannerPractice2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
